export const config = {
  ref_code: "Xo6WI0EG",
  num_ref: 100, // number of references
};
